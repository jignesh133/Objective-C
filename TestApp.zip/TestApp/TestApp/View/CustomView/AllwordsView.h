

#import <UIKit/UIKit.h>

@interface AllwordsView : UIView<UICollectionViewDelegate,UICollectionViewDataSource>{
    NSMutableArray *arrData;
    NSMutableArray *arrIsSelectedPreview;
    
    NSString *strColor;
}


@property(nonatomic,retain)NSMutableArray *arrData,*arrIsSelectedPreview;
@property (retain, nonatomic) IBOutlet UICollectionView *collViewMain;

-(void)relaodColelctionviewData;
+ (id)initWithNib;
@end
