//
//  AllwordsView.m
//  Minnaz
//
//  Created by MAC3 on 2/28/17.
//  Copyright © 2017 app. All rights reserved.
//

#import "AllwordsView.h"
#import "AllwordsCollectionViewCell.h"
#import "Deck.h"
#import "Utils.h"
#import "DeckFlashcards.h"
#import "URLSchema.h"

@implementation AllwordsView
@synthesize arrData,arrIsSelectedPreview;

+ (id)initWithNib {
    AllwordsView*  view = [[[NSBundle mainBundle] loadNibNamed:@"AllwordsView" owner:nil options:nil] objectAtIndex:0];
    UINib *cellNib = [UINib nibWithNibName:@"AllwordsCollectionViewCell" bundle:nil];
    view->strColor = [Utils getFlashCardColor];
    [view.collViewMain registerNib:cellNib forCellWithReuseIdentifier:@"AllwordsCollectionViewCell"];
    return view;
}
-(void)relaodColelctionviewData{
    
    [_collViewMain reloadData];
}
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return arrData.count;
}

-(UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    AllwordsCollectionViewCell *cell = (AllwordsCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"AllwordsCollectionViewCell" forIndexPath:indexPath];
    
    if (cell == nil) {
        NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"AllwordsCollectionViewCell" owner:self options:nil];
        for (id currentObject in topLevelObjects) {
            if ([currentObject isKindOfClass:[UICollectionViewCell class]]) {
                cell =  (AllwordsCollectionViewCell *) currentObject;
                break;
            }
        }
    }
    
    cell.btnTxtToSpeach.tag = indexPath.item;
    [cell.btnTxtToSpeach addTarget:self action:@selector(texttospeachbuttonclicked:) forControlEvents:UIControlEventTouchUpInside];
    
    DeckFlashcards *obj = [arrData objectAtIndex:indexPath.row];
    
    NSArray *arrayAll = [Utils convertStringToArray:obj.meaning_list];
    
   NSMutableArray *googleArray = [[NSMutableArray alloc] init];
   NSMutableArray *lexinArray = [[NSMutableArray alloc] init];
    
    for (NSDictionary *dd in arrayAll) {
        if ([[dd valueForKey:@"dictionary"] isEqualToString:@"google"]) {
            [googleArray addObject:dd];
        }
        if ([[dd valueForKey:@"dictionary"] isEqualToString:@"lexin"]) {
            [lexinArray addObject:dd];
        }
    }
    if ([googleArray count]>0) {
        
        
        NSString *str = [[[[googleArray objectAtIndex:0] valueForKey:@"meanings"] valueForKey:@"word"]componentsJoinedByString:@","];
        if ([str length]>0) {
             cell.lblgoogleWord.text = str;
        }else{
             cell.lblgoogleWord.text = @"No Data Found";}
    }
    else{
         cell.lblgoogleWord.text = @"No Data Found";
    }
    NSString *str;
    if ([lexinArray count]>0) {
        if ([[[[lexinArray objectAtIndex:0] valueForKey:@"meanings"] valueForKey:@"word"] isKindOfClass:[NSArray class]]){
           str = [[[[lexinArray objectAtIndex:0] valueForKey:@"meanings"] valueForKey:@"word"] componentsJoinedByString:@","];
        }
        else{
           str = [[[lexinArray objectAtIndex:0] valueForKey:@"meanings"] valueForKey:@"word"];
        }
        
       
        if ([str length]>0) {
            cell.lbllaxinWord.text = str;
        }else{
            cell.lbllaxinWord.text = @"No Data Found";}
    }
    else{
        cell.lbllaxinWord.text = @"No Data Found";
        
    }
    cell.lblName.text = obj.word;
    cell.lblRearName.text = obj.word;
    if (obj.typeValue==2) {
        NSString *urlString = [NSString stringWithFormat:@"%@%@%@", kBASE_URL, kGetImage, obj.image];
        cell.imgFlashcardImage.url = [NSURL URLWithString:urlString];


    }
    else{
            cell.imgFlashcardImage.url = [NSURL URLWithString:obj.image];
    }
    

    
    if ([[arrIsSelectedPreview objectAtIndex:indexPath.row] isEqual:[NSNumber numberWithBool:true]]) {
        cell.vwFront.hidden = true;
        cell.vwRear.hidden = false;
    }
    else{
        cell.vwFront.hidden = false;
        cell.vwRear.hidden = true;
    }
    if ([strColor length]>0) {
        cell.imgRearbg.hidden = YES;
        cell.imgFrontbg.hidden = YES;
        
        cell.vwRear.backgroundColor = [Utils colorWithHexString:strColor];
        cell.vwFront.backgroundColor = [Utils colorWithHexString:strColor];
        [self SetFlashcardColorViews:cell.vwFront];
        [self SetFlashcardColorViews:cell.vwRear];
        
    }
    else{
        cell.imgRearbg.hidden = NO;
        cell.imgFrontbg.hidden = NO;
        cell.vwRear.backgroundColor = [UIColor whiteColor];
        cell.vwFront.backgroundColor = [UIColor whiteColor];
    }

    

    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    AllwordsCollectionViewCell *datasetCell = (AllwordsCollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    if (![datasetCell.vwFront isHidden]) {
        
        [UIView transitionWithView:datasetCell duration:0.6 options:UIViewAnimationOptionTransitionFlipFromRight animations:^{
            datasetCell.vwFront.hidden = true;
            datasetCell.vwRear.hidden = false;
            [arrIsSelectedPreview replaceObjectAtIndex:indexPath.item withObject:[NSNumber numberWithBool:YES]];
        } completion:^(BOOL finished) {
            
        }];
    }
    else{
        [UIView transitionWithView:datasetCell duration:0.6 options:UIViewAnimationOptionTransitionFlipFromRight animations:^{
            datasetCell.vwFront.hidden = false;
            datasetCell.vwRear.hidden = true;
            [arrIsSelectedPreview replaceObjectAtIndex:indexPath.item withObject:[NSNumber numberWithBool:NO]];
        } completion:^(BOOL finished) {
            
        }];
        
    }
}

-(void)texttospeachbuttonclicked:(id)sender{
    UIButton *tmpbtn = sender;
    DeckFlashcards *obj = [arrData objectAtIndex:[tmpbtn tag]];
    if (obj.word.length > 0) {
        [Utils speechFromText:obj.word];
    }
}

-(void)SetFlashcardColorViews:(id)object{
    UIView *vw = object;
    vw.layer.borderColor = [UIColor lightGrayColor].CGColor;
    vw.layer.cornerRadius = 3.0;
    UIBezierPath *shadowPath = [UIBezierPath bezierPathWithRect:vw.bounds];
    vw.layer.masksToBounds = NO;
    vw.layer.shadowColor = [UIColor darkGrayColor].CGColor;
    vw.layer.shadowOffset = CGSizeMake(0.0f, 2.0f);
    vw.layer.shadowOpacity = 0.5f;
    vw.layer.shadowPath = shadowPath.CGPath;
}

@end
