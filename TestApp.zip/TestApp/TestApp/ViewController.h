//
//  ViewController.h
//  TestApp
//
//  Created by Jignesh Bhensadadiya on 7/2/17.
//  Copyright © 2017 Jignesh Bhensadadiya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PublicPhotosModel.h"
#import "PhotoModel.h"

@interface ViewController : UIViewController
@property (strong, nonatomic) PublicPhotosModel *photosModel;
@property (strong, nonatomic) NSArray<PhotoModel *> *items;

@end

