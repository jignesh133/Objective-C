//
//  ViewController.m
//  TestApp
//
//  Created by Jignesh Bhensadadiya on 7/2/17.
//  Copyright © 2017 Jignesh Bhensadadiya. All rights reserved.
//

#import "ViewController.h"
#import "PhotoModel.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"post" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    NSArray *json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    NSMutableArray *jokes = [[NSMutableArray alloc] init];
    NSArray *arr = [json valueForKey:@"posts"];
//    jokes = [JokeModel arrayOfDictionariesFromModels:arr];

    
    [self fetchPhotos];
}

- (void)fetchPhotos {
    NSURL *photosURL = [NSURL URLWithString:@"https://api.flickr.com/services/feeds/photos_public.gne?id=46760712@N07&lang=en-us&format=json&nojsoncallback=1"];
    
    [[[NSURLSession sharedSession] dataTaskWithURL:photosURL completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        // Process Data
        
        NSString* rawJSON = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        rawJSON = [rawJSON stringByReplacingOccurrencesOfString:@"\\'" withString:@"'"];
        
        self.photosModel = [[PublicPhotosModel alloc] initWithString:rawJSON error:nil];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            self.title = self.photosModel.title;
        });
        NSError *error1;

        NSMutableDictionary * innerJson = [NSJSONSerialization
                                           JSONObjectWithData:data options:kNilOptions error:&error1];

        @try {
            
            self.photosModel =  [[PublicPhotosModel alloc] initWithDictionary:innerJson error:nil];
                    self.items = [PhotoModel arrayOfModelsFromDictionaries:[innerJson valueForKey:@"items"] error:nil ];
            
            NSLog(@"%@",self.items);
            
        } @catch (NSException *exception) {
            NSLog(@"%@",exception);
        }

        
        
    }] resume];
}


    
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
