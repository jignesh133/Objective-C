//
//  main.m
//  TestApp
//
//  Created by Jignesh Bhensadadiya on 7/2/17.
//  Copyright © 2017 Jignesh Bhensadadiya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
