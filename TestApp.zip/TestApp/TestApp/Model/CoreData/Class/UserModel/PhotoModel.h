//
//  PhotoModel.h
//  TestApp
//
//  Created by Jignesh Bhensadadiya on 7/3/17.
//  Copyright © 2017 Jignesh Bhensadadiya. All rights reserved.
//

#import <JSONModel/JSONModel.h>

@interface PhotoModel : JSONModel
@property (copy, nonatomic) NSString *title;
@property (strong, nonatomic) NSURL *url;
@property (strong, nonatomic) NSURL *link;
@property (strong, nonatomic) NSDate *published;
@end
