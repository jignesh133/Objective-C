//
//  PublicPhotosModel.h
//  TestApp
//
//  Created by Jignesh Bhensadadiya on 7/3/17.
//  Copyright © 2017 Jignesh Bhensadadiya. All rights reserved.
//

#import <JSONModel/JSONModel.h>
#import "PhotoModel.h"

@interface PublicPhotosModel : JSONModel

@property (copy, nonatomic) NSString *title;
@property (strong, nonatomic) NSDate *modified;

@property (strong, nonatomic) PhotoModel *items;
@end
