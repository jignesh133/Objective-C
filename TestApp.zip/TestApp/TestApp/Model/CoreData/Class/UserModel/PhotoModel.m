//
//  PhotoModel.m
//  TestApp
//
//  Created by Jignesh Bhensadadiya on 7/3/17.
//  Copyright © 2017 Jignesh Bhensadadiya. All rights reserved.
//

#import "PhotoModel.h"

@implementation PhotoModel
+ (JSONKeyMapper*)keyMapper {
    NSDictionary *map = @{ @"published": @"date",
                           @"media.m"  : @"url" };
    
    return [[JSONKeyMapper alloc] initWithDictionary:map];
}
@end
