//
//  TagModel.m
//  TestApp
//
//  Created by Jignesh Bhensadadiya on 7/2/17.
//  Copyright © 2017 Jignesh Bhensadadiya. All rights reserved.
//

#import "TagModel.h"

@implementation TagModel

@end
