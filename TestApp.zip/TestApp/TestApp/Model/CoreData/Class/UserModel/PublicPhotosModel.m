//
//  PublicPhotosModel.m
//  TestApp
//
//  Created by Jignesh Bhensadadiya on 7/3/17.
//  Copyright © 2017 Jignesh Bhensadadiya. All rights reserved.
//

#import "PublicPhotosModel.h"

@implementation PublicPhotosModel

@end
