//
//  TagModel.h
//  TestApp
//
//  Created by Jignesh Bhensadadiya on 7/2/17.
//  Copyright © 2017 Jignesh Bhensadadiya. All rights reserved.
//

#import <JSONModel/JSONModel.h>
#import "TagModel.h"

@interface TagModel : JSONModel

@property (strong, nonatomic) NSArray *tags;

    
@end
