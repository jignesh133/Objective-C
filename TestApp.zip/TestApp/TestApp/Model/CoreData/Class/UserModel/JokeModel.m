//
//  JokeModel.m
//  TestApp
//
//  Created by Jignesh Bhensadadiya on 7/2/17.
//  Copyright © 2017 Jignesh Bhensadadiya. All rights reserved.
//

#import "JokeModel.h"

@implementation JokeModel

@end
