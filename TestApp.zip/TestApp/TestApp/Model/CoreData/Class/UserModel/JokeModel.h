//
//  JokeModel.h
//  TestApp
//
//  Created by Jignesh Bhensadadiya on 7/2/17.
//  Copyright © 2017 Jignesh Bhensadadiya. All rights reserved.
//

#import <JSONModel/JSONModel.h>

@interface JokeModel : JSONModel

    @property (assign, nonatomic) int  postid;
    @property (strong, nonatomic) NSString* name;
    
@end
