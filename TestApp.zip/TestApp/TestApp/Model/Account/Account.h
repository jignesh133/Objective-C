
#import <Foundation/Foundation.h>
#import "AccountAuthenticateDelegate.h"
#import "Request.h"
#import "RequestManager.h"


typedef enum : NSUInteger {
    RequestEmail =0,
    RequestUsername =1,
    RequestEditUser = 2,
} AccountRequestType;

@interface Account : NSObject<NSCoding,RequestDelegate>
@property (nonatomic) BOOL isActivated;
@property (nonatomic ,retain) NSString * nwPassword;
@property (nonatomic ,retain) UIImage * imgavarar;
@property (nonatomic ,retain) NSString *strMessage;
@property (nonatomic ,retain) NSString * email;
@property (nonatomic ,retain) NSString * user_id;
@property (nonatomic ,retain) NSString * location;
@property (nonatomic ,retain) NSString * user_name;
@property (nonatomic ,retain) NSString * password;
@property (nonatomic ,retain) NSString * phone_number;
@property (nonatomic ,retain) NSMutableDictionary * school;
@property (nonatomic ,retain) NSString * provider;
@property (nonatomic ,retain) NSMutableArray *friends;
@property (nonatomic ,retain) NSString * facebook_id;
@property (nonatomic ,retain) NSString * google_id;
@property (nonatomic ,retain) NSString * role;
@property (nonatomic ,retain) NSString * token;
@property (nonatomic ,retain) NSString * website;
@property (nonatomic ,retain) NSString * full_name;
@property (nonatomic ,retain) NSString * first_name;
@property (nonatomic ,retain) NSString * last_name;
@property (nonatomic ,retain) NSString * avatar;
@property (nonatomic ,retain) NSString * gender;
@property (nonatomic ,retain) NSString * classId;
@property (nonatomic ,retain) NSString * deviceID;

@property (nonatomic) BOOL is_verify,is_blocked;

@property (nonatomic ,assign) AccountRequestType type;

@property (nonatomic, retain) id<AccountAuthenticateDelegate> delegate;

- (void)authenticateUserAccountDelegate:(id<AccountAuthenticateDelegate>)del;
- (void)authenticateSocialUserAccountDelegate:(id<AccountAuthenticateDelegate>)del;
- (void)registerUserAccountDelegate:(id<AccountAuthenticateDelegate>)del;
- (void)forgotPasswordWithAccountDelegate:(id<AccountAuthenticateDelegate>)del;
- (void)authenticateEditUserAccountDelegate:(id<AccountAuthenticateDelegate>)del;
- (void)uploadAvtar:(UIImage *)img WithDelegate:(id<AccountAuthenticateDelegate>) del;
- (void)updateUserAccountDelegate:(NSMutableDictionary *)data :(id<AccountAuthenticateDelegate>)del;
- (void)changePasswordWithAccountDelegate:(id<AccountAuthenticateDelegate>)del;
- (void)updateAvtar:(UIImage *)img WithDelegate:(id<AccountAuthenticateDelegate>) del;
- (void)DeviceInfoForUserAccountDelegate:(id<AccountAuthenticateDelegate>)del;
- (void)updateAccountWithDelegate:(id<AccountAuthenticateDelegate>) del;
@end
