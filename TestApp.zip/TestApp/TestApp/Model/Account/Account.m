
#import "Account.h"
#import "URLSchema.h"
//#import "Constants.h"
#import "AppDelegate.h"

#define ENCODING_VERSION        2

@implementation Account

-(id)init{
    self = [super init];
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super init];
    if (self) {
        //imgavarar
        _classId = [aDecoder decodeObjectForKey:@"classId"];
        
        _avatar = [aDecoder decodeObjectForKey:@"avatar"];
        _user_id = [aDecoder decodeObjectForKey:@"_id"];
        _email = [aDecoder decodeObjectForKey:@"email"];
        _school = [aDecoder decodeObjectForKey:@"school"];

        _user_name = [aDecoder decodeObjectForKey:@"user_name"];
        _role = [aDecoder decodeObjectForKey:@"role"];
        _provider = [aDecoder decodeObjectForKey:@"provider"];
        _token = [aDecoder decodeObjectForKey:@"token"];
        _full_name = [aDecoder decodeObjectForKey:@"full_name"];
        _location = [aDecoder decodeObjectForKey:@"location"];
        _gender = [aDecoder decodeObjectForKey:@"gender"];
        _gender =  [aDecoder decodeObjectForKey:@"gender"];
        _first_name =  [aDecoder decodeObjectForKey:@"first_name"];
        _last_name =  [aDecoder decodeObjectForKey:@"last_name"];
        _is_verify =  [aDecoder decodeObjectForKey:@"is_verify"];
                _is_blocked =  [aDecoder decodeObjectForKey:@"is_blocked"];
    }
    
    return self;
}

-(void)encodeWithCoder:(NSCoder *)aCoder {
    
    [aCoder encodeObject:_classId forKey:@"classId"];
    
    [aCoder encodeObject:_first_name forKey:@"first_name"];
    [aCoder encodeObject:_last_name forKey:@"last_name"];
    [aCoder encodeObject:_imgavarar forKey:@"imgavarar"];
    [aCoder encodeObject:_avatar forKey:@"avatar"];
    [aCoder encodeObject:_gender forKey:@"gender"];
    [aCoder encodeObject:_user_id forKey:@"_id"];
    [aCoder encodeObject:_token forKey:@"token"];
    [aCoder encodeObject:_email forKey:@"email"];
    [aCoder encodeObject:_user_name forKey:@"user_name"];
    [aCoder encodeObject:_facebook_id forKey:@"facebook_id"];
    [aCoder encodeObject:_role forKey:@"role"];
    [aCoder encodeObject:_provider forKey:@"provider"];
    [aCoder encodeObject:_user_name forKey:@"fullname"];
    [aCoder encodeObject:_website forKey:@"website"];
    [aCoder encodeObject:_location forKey:@"location"];
    [aCoder encodeObject:_facebook_id forKey:@"facebook_id"];
    [aCoder encodeObject:_gender forKey:@"gender"];
    [aCoder encodeObject:[NSNumber numberWithBool:_is_verify] forKey:@"is_verify"];
    [aCoder encodeObject:_school forKey:@"school"];
    [aCoder encodeObject:[NSNumber numberWithBool:_is_blocked] forKey:@"is_blocked"];
    
    
}
- (void)changePasswordWithAccountDelegate:(id<AccountAuthenticateDelegate>)del{
    _delegate = del;
    Request *request = [[Request alloc] initWithUrl:kChangePassword andDelegate:self andMethod:POST];
    [request setParameter:self.password forKey:@"old_password"];
    [request setParameter:self.nwPassword forKey:@"new_password"];
    request.Tag = kChangePassword;
    [request startRequest];
}

- (void)uploadAvtar:(UIImage *)img WithDelegate:(id<AccountAuthenticateDelegate>) del{
    _delegate=del;
    NSString * urlString = [NSString stringWithFormat:@"%@", kUploadUserAvatar];
    Request *request = [[Request alloc] initWithUrl:urlString andDelegate:self andMethod:MULTI_PART_FORM];

    CGFloat compression = 0.9f;
    CGFloat maxCompression = 0.1f;
    int maxFileSize = 250*1024;
    
    NSData *imageData = [NSData dataWithData:UIImageJPEGRepresentation(img, 1)];
    
    while ([imageData length] > maxFileSize && compression > maxCompression)
    {
        compression -= 0.1;
        imageData = UIImageJPEGRepresentation(img, compression);
    }
    
    [request setParameter:imageData forKey:@"file"];
    request.Tag = kUploadUserAvatar;
    [request startRequest];
}

- (void)updateAvtar:(UIImage *)img WithDelegate:(id<AccountAuthenticateDelegate>) del{
    _delegate=del;
    NSString * urlString = [NSString stringWithFormat:@"%@", kUpdateAccountAvatar];
    Request *request = [[Request alloc] initWithUrl:urlString andDelegate:self andMethod:MULTI_PART_FORM];
    NSData *imageData = [NSData dataWithData:UIImageJPEGRepresentation(img, 0.6)];
    [request setParameter:imageData forKey:@"file"];
    request.Tag = kUpdateAccountAvatar;
    [request startRequest];
}

- (void)registerUserAccountDelegate:(id<AccountAuthenticateDelegate>)del{
    _delegate = del;
    Request *request = [[Request alloc] initWithUrl:kRegister andDelegate:self andMethod:POST];
    
    if ([self.provider isEqualToString:@"facebook"]) {
        [request setParameter:self.facebook_id forKey:@"facebook_id"];
    }
    
    if ([self.provider isEqualToString:@"google"]) {
        [request setParameter:self.google_id forKey:@"google_id"];
    }
    if (self.role.length > 0) {
        [request setParameter:self.role forKey:@"role"];
        [request setParameter:self.first_name forKey:@"first_name"];
    }
    if ([self.last_name length]>0) {
    [request setParameter:self.last_name forKey:@"last_name"];
    }
    [request setParameter:self.email forKey:@"email"];
    [request setParameter:self.provider forKey:@"provider"];
    [request setParameter:self.full_name forKey:@"full_name"];
    [request setParameter:self.user_name forKey:@"user_name"];
    [request setParameter:self.password forKey:@"password"];
    [request setParameter:self.phone_number forKey:@"phone_number"];
    
//    [request setParameter:self.password forKey:@"password"];
//    [request setParameter:self.phone_number forKey:@"phone_number"];
//    
    
    request.Tag = kRegister;
    [request startRequest];
}

- (void)authenticateSocialUserAccountDelegate:(id<AccountAuthenticateDelegate>)del{
    _delegate = del;
    Request *request = [[Request alloc] initWithUrl:kSocialLogin andDelegate:self andMethod:POST];
    
    if ([self.provider isEqualToString:@"facebook"]) {
        [request setParameter:self.facebook_id forKey:@"facebook_id"];
        [request setParameter:self.first_name forKey:@"first_name"];
        [request setParameter:self.last_name forKey:@"last_name"];
    }
    
    if ([self.provider isEqualToString:@"google"]) {
        [request setParameter:self.google_id forKey:@"google_id"];
    }
//    [request setParameter:self.phone_number forKey:@"phone_number"];
    [request setParameter:@"normal" forKey:@"role"];
    [request setParameter:self.email forKey:@"email"];
    [request setParameter:self.provider forKey:@"provider"];
    [request setParameter:self.full_name forKey:@"full_name"];
    [request setParameter:self.user_name forKey:@"user_name"];
    [request setParameter:@"true" forKey:@"from_app"];
    request.Tag = kSocialLogin;
    [request startRequest];
}

- (void)authenticateUserAccountDelegate:(id<AccountAuthenticateDelegate>)del{
    _delegate = del;
    Request *request = [[Request alloc] initWithUrl:kLogin andDelegate:self andMethod:POST];
    [request setParameter:self.user_name forKey:@"user_name"];
    [request setParameter:self.password forKey:@"password"];
    [request setParameter:@"true" forKey:@"from_app"];
    request.Tag = kLogin;
    [request startRequest];
}
/*
-(void)DeviceInfoForUserAccountDelegate:(id<AccountAuthenticateDelegate>)del{
    _delegate = del;
    Request *request = [[Request alloc] initWithUrl:kUpdateToken andDelegate:self andMethod:POST];
    [request setParameter:self.user_id forKey:@"_id"];
    NSString *strId = [[AppDelegate appDelegate] strTokenId];
    if ([strId length]==0) {
        strId = @"123456";
    }
    NSDictionary *parameters =  @{ @"device_id": strId, @"device_type": @"ios" };
    request.Tag= kUpdateToken;
    
    [request setParameter:self.user_id forKey:@"_id"];
    [request setParameter:parameters forKey:@"device_info"];
    
    [request startRequest];
}
*/
- (void)forgotPasswordWithAccountDelegate:(id<AccountAuthenticateDelegate>)del{
    _delegate = del;
    Request *request = [[Request alloc] initWithUrl:kForgotPassword andDelegate:self andMethod:POST];
    [request setParameter:self.email forKey:@"email"];
    request.Tag = kForgotPassword;
    [request startRequest];
}
-(void)updateUserAccountDelegate:(NSMutableDictionary *)data :(id<AccountAuthenticateDelegate>)del{
    _delegate = del;
    Request *request = [[Request alloc] initWithUrl:kUpdateAccount andDelegate:self andMethod:POST];
    [request setParameter:self.email forKey:@"email"];
    [request setParameter:self.user_id forKey:@"_id"];
    [request setParameter:self.user_name forKey:@"user_name"];
    
    NSString *str= [data valueForKey:@"name"];
    NSArray *arr = [str componentsSeparatedByString:@","];
    
    [request setParameter:[arr objectAtIndex:0] forKey:@"first_name"];
    if ([arr count]>1) {
      [request setParameter:[arr objectAtIndex:1]  forKey:@"last_name"];
    }
    else{
        [request setParameter:@"" forKey:@"last_name"];
        
    }

    [request setParameter:@"male" forKey:@"gender"];
    [request setParameter:[data valueForKey:@"phone_number"] forKey:@"phone_number"];
    [request setParameter:[data valueForKey:@"settings"] forKey:@"settings"];
    
    
    request.Tag = kUpdateAccount;
    [request startRequest];
}
-(void)updateAccountWithDelegate:(id<AccountAuthenticateDelegate>)del{
  _delegate = del;
    Request *request = [[Request alloc] initWithUrl:kgetUser andDelegate:self andMethod:GET];
    request.Tag = kgetUser;
    [request startRequest];
    
}
#pragma RequestDelegate
-(void)RequestDidSuccess:(Request *)request{
    if (request.IsSuccess) {
        if ([request.Tag isEqualToString:kUpdateToken]) {
           
        }
        if ([request.Tag isEqualToString:kUpdateAccountAvatar]) {
            self.avatar = [request.serverData valueForKey:@"data"];
        }
        if ([request.Tag isEqualToString:kUpdateAccount]) {
            NSMutableDictionary * dict = request.serverData;

            NSMutableDictionary * data = [dict valueForKey:@"data"];
            
            if ([data objectForKey:@"full_name"]) {
                self.full_name = [data objectForKey:@"full_name"];
            }
            if ([data objectForKey:@"first_name"]) {
                self.first_name = [data objectForKey:@"first_name"];
            }
            if ([data objectForKey:@"last_name"]) {
                self.last_name = [data objectForKey:@"last_name"];
            }
            if ([data objectForKey:@"phone_number"]) {
                self.phone_number = [data objectForKey:@"phone_number"];
            }
            if ([data objectForKey:@"avatar"]) {
                self.avatar = [data objectForKey:@"avatar"];
            }
            if ([data objectForKey:@"gender"]) {
                self.gender = [data objectForKey:@"gender"];
            }
            if ([dict valueForKey:@"message"]) {
                self.strMessage = [dict valueForKey:@"message"];
            }
            [AccountManager Instance].activeAccount = self;
            [[AccountManager Instance] saveAccount];
        }
       else if ([request.Tag isEqualToString:kLogin] || [request.Tag isEqualToString:kEmailLogin] || [request.Tag isEqualToString:kSocialLogin] || [request.Tag isEqualToString:kRegister]  || [request.Tag isEqualToString:kgetUser]) {
            
            NSMutableDictionary * dict = request.serverData;
          
            if ([dict valueForKey:@"message"]) {
                self.strMessage = [dict valueForKey:@"message"];
            }
            
            if (![[dict valueForKey:@"data"] isEqual:[NSNull null]]) {
                NSMutableDictionary * data = [dict valueForKey:@"data"];
                
                if ([data objectForKey:@"token"]) {
                    self.token = [data objectForKey:@"token"];
                }
                
                NSMutableDictionary * user = [data valueForKey:@"user"];
                self.isActivated = YES;
                if ([user objectForKey:@"full_name"]) {
                    self.full_name = [user objectForKey:@"full_name"];
                }
                if ([user objectForKey:@"first_name"]) {
                    self.first_name = [user objectForKey:@"first_name"];
                }
                if ([user objectForKey:@"avatar"]) {
                    self.avatar = [user objectForKey:@"avatar"];
                }
                if ([user valueForKey:@"classId"]) {
                    if ([[user valueForKey:@"classId"] isEqual:[NSNull null]] || [[user valueForKey:@"classId"] length]==0) {
                        self.classId = @"";
                    }
                    else{
                        self.classId = [user valueForKey:@"classId"];
                    }
                }
                
                if ([user objectForKey:@"last_name"]) {
                    self.last_name = [user objectForKey:@"last_name"];
                }
                if ([user objectForKey:@"email"]) {
                    self.email = [user objectForKey:@"email"];
                }
                if (![[user valueForKey:@"phone_number"] isEqual:[NSNull null]]) {
                    if ([user objectForKey:@"phone_number"]) {
                        self.phone_number = [user objectForKey:@"phone_number"];
                    }
                }
                else{
                self.phone_number = @"";
                }
               
                if ([user objectForKey:@"is_verify"]) {
                    self.is_verify = [[user objectForKey:@"is_verify"] boolValue];
                }
                if ([user objectForKey:@"is_blocked"]) {
                    self.is_blocked = [[user objectForKey:@"is_blocked"] boolValue];
                }
                if ([user objectForKey:@"role"]) {
                    self.role = [user objectForKey:@"role"];
                }
                if ([user objectForKey:@"provider"]) {
                    self.provider = [user objectForKey:@"provider"];
                }
                if ([user objectForKey:@"friends"]) {
                    self.friends = [user objectForKey:@"friends"];
                }
                if ([user objectForKey:@"website"]) {
                    self.website = [user objectForKey:@"website"];
                }
                if ([user objectForKey:@"avatar"]) {
                    self.avatar = [user objectForKey:@"avatar"];
                }
                if ([user objectForKey:@"school"]) {
                    self.school = [user objectForKey:@"school"];
                }
                
                if ([user objectForKey:@"gender"]) {
                    self.gender = [user objectForKey:@"gender"];
                }
                self.user_id = [user valueForKey:@"_id"];
            }
            else{
                self.isActivated = NO;
            }
        }
       else if ([request.Tag isEqualToString:kUser] ) {
            
            if ([request.serverData objectForKey:@"data"] && ![[request.serverData objectForKey:@"data"] isEqual:[NSNull null] ]) {
                
                NSDictionary * dataDict = [request.serverData objectForKey:@"data"];
                
                if ([dataDict objectForKey:@"first_name"]) {
                    self.first_name = [dataDict objectForKey:@"first_name"];
                }
                if ([dataDict objectForKey:@"last_name"]) {
                    self.last_name = [dataDict objectForKey:@"last_name"];
                }
                if ([dataDict objectForKey:@"full_name"]) {
                    self.full_name = [dataDict objectForKey:@"full_name"];
                }
                if ([dataDict objectForKey:@"token"]) {
                    self.token = [dataDict objectForKey:@"token"];
                }
                if ([dataDict objectForKey:@"email"]) {
                    self.email = [dataDict objectForKey:@"email"];
                }
                if ([dataDict objectForKey:@"location"]) {
                    self.location = [dataDict objectForKey:@"location"];
                }
                if ([dataDict objectForKey:@"website"]) {
                    self.website = [dataDict objectForKey:@"website"];
                }
                if ([dataDict objectForKey:@"avatar"]) {
                    self.avatar = [dataDict objectForKey:@"avatar"];
                }
                if ([dataDict objectForKey:@"school"]) {
                    self.school = [dataDict objectForKey:@"school"];
                }
                if ([dataDict objectForKey:@"gender"]) {
                    self.gender = [dataDict objectForKey:@"gender"];
                }
                if ([dataDict objectForKey:@"facebook_id"]) {
                    self.facebook_id = [dataDict objectForKey:@"facebook_id"];
                }
                if ([dataDict objectForKey:@"is_verify"]) {
                    self.is_verify = [[dataDict objectForKey:@"is_verify"] boolValue];
                }
            }
        }
        
       else if ([request.Tag isEqualToString:kChangePassword] ) {
           
       }
        
        if (_delegate && [_delegate respondsToSelector:@selector(accountAuthenticatedWithAccount:)]) {
            [_delegate accountAuthenticatedWithAccount:self];
        }
    }
}

-(void)RequestDidFailForRequest:(Request *)request withError:(NSError *)error{
    if ([error.userInfo objectForKey:@"message"]) {
        [_delegate accountDidFailAuthentication:[error.userInfo objectForKey:@"message"]];
    }
    else{
     [_delegate accountDidFailAuthentication:[error localizedDescription]];
    }
}

@end
