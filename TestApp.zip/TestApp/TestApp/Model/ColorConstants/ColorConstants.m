
#import "ColorConstants.h"

#define RGB(r,g,b) \
{ \
static UIColor *rgb; \
if(!rgb) \
rgb = [UIColor colorWithRed: r / 255.0 green: g / 255.0 blue: b / 255.0 alpha: 1.0]; \
return rgb; \
}

#define RGBA(r,g,b,a) \
{ \
static UIColor *rgb; \
if(!rgb) \
rgb = [UIColor colorWithRed: r / 255.0 green: g / 255.0 blue: b / 255.0 alpha: a]; \
return rgb; \
}

@implementation ColorConstants

+ (UIColor *)appBlueColor                     RGB(41, 62, 83)
+ (UIColor *)appProgressBorderColor                     RGB(173, 175, 179)
+ (UIColor *)appProgressFillColor                     RGB(45, 61, 82)
+ (UIColor *)appProgressInnerBorderColor                     RGB(0, 32, 64)
+ (UIColor *)appCombineChart                     RGB(9, 162, 196)
+(UIColor *)appPageIndicator RGB(0, 255, 255)
+ (UIColor *)appCombineChartLineChart                     RGB(115, 214, 255)
+ (UIColor *)appCombineChartbarChart                     RGB(19, 162, 196)
@end
