
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface ColorConstants : NSObject

+ (nonnull UIColor *)appBlueColor;
+ (nonnull UIColor *)appProgressBorderColor;
+ (nonnull UIColor *)appProgressFillColor;
+ (nonnull UIColor *)appProgressInnerBorderColor;
+ (nonnull UIColor *)appCombineChart;

+ (nonnull UIColor *)appCombineChartLineChart;
+ (nonnull UIColor *)appCombineChartbarChart;
+(nonnull UIColor *)appPageIndicator;
@end
